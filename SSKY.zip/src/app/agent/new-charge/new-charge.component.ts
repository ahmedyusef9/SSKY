import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-charge',
  templateUrl: './new-charge.component.html',
  styleUrls: ['./new-charge.component.scss']
})
export class NewChargeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
