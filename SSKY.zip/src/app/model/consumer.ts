export class Consumer {
    id: number;
    username: string;
    email: string;
    firstname: string;
    lastname: string;
    phone: string;
    mobile: string;
    national_id:string;
    birthday: string;
    birthday_sec: string;
    created_at: string;
    created_at_sec: string;
    last_update: string;
    last_update_sec: string;
    level_id: number=4;
    parent:number=0;
    parent_name:string;
    payment_methods:string;
}