export class ProductAgent {
    id: number;
    profit: number;
    discount: number;
    created_at: string;
    created_at_sec: string;
    last_update: string;
    last_update_sec: string;
    agent_id: number;
    product_id:number;
    note:string;
}