export class AgentDiscount {
    user_id: number;
    discount: number;
    product_id:number;
}