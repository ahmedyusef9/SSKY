import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-payments',
  templateUrl: './agent-payments.component.html',
  styleUrls: ['./agent-payments.component.scss']
})
export class AgentPaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
