export class Company {
    id: number;
    name: string;
    name_ar: string;
    name_en: string;
    created_at: string='';
    created_at_sec: string='';
    last_update: string='';
    last_update_sec:string='';
}