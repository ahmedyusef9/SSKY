import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-agreement',
  templateUrl: './add-agreement.component.html',
  styleUrls: ['./add-agreement.component.scss']
})
export class AddAgreementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
