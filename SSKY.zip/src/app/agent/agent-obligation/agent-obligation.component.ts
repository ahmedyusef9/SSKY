import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-obligation',
  templateUrl: './agent-obligation.component.html',
  styleUrls: ['./agent-obligation.component.scss']
})
export class AgentObligationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
