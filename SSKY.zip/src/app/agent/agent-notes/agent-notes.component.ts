import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-notes',
  templateUrl: './agent-notes.component.html',
  styleUrls: ['./agent-notes.component.scss']
})
export class AgentNotesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
