import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-obligation-update',
  templateUrl: './obligation-update.component.html',
  styleUrls: ['./obligation-update.component.scss']
})
export class ObligationUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
