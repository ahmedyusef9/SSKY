export class Level {
    id: number;
    name: string;
    description:string;
    created_at: string;
    created_at_sec: string;
    last_update: string;
    last_update_sec:string;
}