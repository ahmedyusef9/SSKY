export class ServerDateTime {
    d: string;
    t: string;
}