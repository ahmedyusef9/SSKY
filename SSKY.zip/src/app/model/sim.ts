export class Sim {
    id: number;
    sim: string;
    note: string
    used: Boolean;
    created_at: string;
    created_at_sec: string;
    last_update: string;
    last_update_sec: string;
    agent_id: number;
    agent_name:string;
    company_id:number;
    company_name:string; 
    company_name_ar:string; 
    company_name_en:string; 
}
