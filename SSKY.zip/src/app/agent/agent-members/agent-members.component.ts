import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-members',
  templateUrl: './agent-members.component.html',
  styleUrls: ['./agent-members.component.scss']
})
export class AgentMembersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
