import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-agreement',
  templateUrl: './agent-agreement.component.html',
  styleUrls: ['./agent-agreement.component.scss']
})
export class AgentAgreementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
