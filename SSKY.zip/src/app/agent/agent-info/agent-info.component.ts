import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-info',
  templateUrl: './agent-info.component.html',
  styleUrls: ['./agent-info.component.scss']
})
export class AgentInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
