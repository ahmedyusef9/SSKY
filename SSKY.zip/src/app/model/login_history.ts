export class LoginHistory {
    id: number;
    user_id: number;
    login: string;
    login_sec:string;
    logout: string;
    logout_sec: string;
    created_at: string;
    created_at_sec:string;
    last_update: string;
    last_update_sec:string;
}