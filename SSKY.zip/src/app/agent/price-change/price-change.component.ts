import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-price-change',
  templateUrl: './price-change.component.html',
  styleUrls: ['./price-change.component.scss']
})
export class PriceChangeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
