import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from "src/app/home/home/home.component";
import { AuthGuard } from "src/app/login/auth.guard";
import { LoginComponent } from './login/login/login.component';

const routes: Routes = [
  { path: '',component: HomeComponent , canActivate: [AuthGuard]},
  { path: 'התחברות', component: LoginComponent },
  { path: '**', redirectTo: '', canActivate: [AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
