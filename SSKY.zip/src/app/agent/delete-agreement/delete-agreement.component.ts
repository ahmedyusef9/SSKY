import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-agreement',
  templateUrl: './delete-agreement.component.html',
  styleUrls: ['./delete-agreement.component.scss']
})
export class DeleteAgreementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
